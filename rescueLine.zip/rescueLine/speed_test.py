#!/usr/bin/env pybricks-micropython

import time
import struct

from pybricks.hubs import EV3Brick
from pybricks.iodevices import UARTDevice
from pybricks.parameters import Port
from pybricks.media.ev3dev import SoundFile
from tools import StopWatch, wait

rcvPACKET = b''

def readPacket() -> bool:
    global PacketIndex
    global ObjectIndex
    global rcvPACKET
    global ObjectCount
    
    read = False

    rcvPACKET = bytearray([])
    rcvPACKET += ser.read()
    PacketIndex = 0
    if rcvPACKET[0] == 0xAA:
        PacketIndex = 1
        rcvPACKET += ser.read()
        if rcvPACKET[1] == 0xCC:
            PacketIndex = 2

            rcvPACKET += ser.read(4)    # TOF1 거리 2 Bytes Unsigned Integer
            rcvPACKET += ser.read(4)    # TOF2 거리 2 Bytes Unsigned Integer
            rcvPACKET += ser.read(4)    # TOF3 거리 2 Bytes Unsigned Integer
            rcvPACKET += ser.read(4)    # YAW 값 4 Bytes Float

            rcvPACKET += ser.read() #CHECKSUM

            chksum = 0
            for r in rcvPACKET:     #CHECKSUM 계산
                chksum ^= r
                
            if chksum != 0:         #CHECKSUM ERROR
                print("CHECK SUM ERROR")
                return False

            return True
    return False


# rcvPACKETs = []
# def readPacket(t):
#     global rcvPACKETs
#     rcvPACKET = bytearray([])
#     rcvPACKET += ser.read(3)
#     if 0xAA in :




ser = UARTDevice(Port.S3, 115200)
ser.clear()
wait(100)
print("df")
while True:
    read = True
    if ser.waiting() >= 5:  # 수신 데이터가 있으면 (최소 사이즈는 5 바이트임)
        wait(1) 
        if readPacket():    # 데이터 수신에 성공했으면 Parsing 함
            tof1 = struct.unpack("<H",rcvPACKET[3:7])[0]
            tof2 = struct.unpack("<H",rcvPACKET[7:11])[0]
            tof3 = struct.unpack("<H",rcvPACKET[11:15])[0]
            tof4 = struct.unpack("<H",rcvPACKET[15:19])[0]
            tof5 = struct.unpack("<H",rcvPACKET[19:23])[0]
            print("OK")
            print("TOF1  : ",tof1)
            print("TOF2  : ",tof2)
            print("TOF3  : ",tof3)
            print("TOF4  : ",tof4)
            print("TOF5  : ",tof5)
        else:
            print("PACKET READING ERROR")
    else:
        print("failed")
    print(rcvPACKET)
    wait(100)
