def adjust_roll(initial_roll, current_roll):
    adjusted_roll=current_roll-initial_roll
    print(adjusted_roll)
    if adjusted_roll > 180:
        adjusted_roll-=360
    elif adjusted_roll < -180:
        adjusted_roll+=360
    return adjusted_roll
# a=adjust_roll(330,200)
# print(a)


def update_yaw(now_yaw, angle):
    if angle > 0:
        now_yaw += angle
        if now_yaw >= 360:
            now_yaw -= 360
    elif angle < 0:
        now_yaw += angle
        if now_yaw < 0:
            now_yaw += 360
    return now_yaw

# 예제 사용법


# 시계방향으로 회전 (angle > 0)
yaw = update_yaw(10, 360)
print(f"시계방향 회전 후 yaw 값: {yaw}")

# 반시계방향으로 회전 (angle < 0)
yaw = update_yaw(330, -70)
print(f"반시계방향 회전 후 yaw 값: {yaw}")
