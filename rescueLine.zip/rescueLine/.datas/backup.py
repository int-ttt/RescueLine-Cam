#!/usr/bin/env pybricks-micropython

import time
import struct, math

from pybricks.hubs import EV3Brick
from pybricks.ev3devices import (Motor, TouchSensor, ColorSensor,
                                 InfraredSensor, UltrasonicSensor, GyroSensor)
from pybricks.parameters import Port, Stop, Direction, Button, Color
from pybricks.tools import wait, StopWatch, DataLog
from pybricks.robotics import DriveBase
from pybricks.media.ev3dev import SoundFile, ImageFile
from ucollections import namedtuple
from pybricks.iodevices import UARTDevice

stop_watch = StopWatch()

PacketIndex = 0;ObjectIndex = 0;rcvPACKET = bytearray([]);Object = list([]);ObjectCount = 0
def _parsing(_data) -> tuple([uInt16, uInt16, uInt16, uInt16, uInt16]):
    buf = struct.unpack("<hhhhh", _data)
    return tuple(buf)

def readPacket() -> bool:
    global PacketIndex
    global ObjectIndex
    global rcvPACKET
    global ObjectCount
    global yaw, roll, pitch
    read = False
    rcvPACKET = bytearray([])
    rcvPACKET += ser.read()
    if rcvPACKET[0] == 0xAA or rcvPACKET[0] == '\x00':
        rcvPACKET += ser.read()
        if rcvPACKET[1] == 0xCC:
            rcvPACKET += ser.read()     # PACKET SeqNo
            rcvPACKET += ser.read(2)    # TOF1 거리 2 Bytes Unsigned Integer
            rcvPACKET += ser.read(2)    # TOF2 거리 2 Bytes Unsigned Integer
            rcvPACKET += ser.read(4)    # YAW 값 4 Bytes Float
            rcvPACKET += ser.read(4)    # ROLL 값 4 Bytes Float
            rcvPACKET += ser.read(4)    # PITCH 값 4 Bytes Float
            rcvPACKET += ser.read()     # OBJECT 갯수 1 Bytes Unsigned Integer
            ObjectCount = rcvPACKET[19]             
            timeStamp = time.time()
            while ser.waiting() < ObjectCount * 10 + 1 and time.time() - timeStamp < 1:   #100ms 이내에 모든 data가 들어오길 기다린다.
                pass
            wait(1)
            if ser.waiting() < ObjectCount * 10 + 1:     #정확한 사이즈의 DATA가 수신되지 않았음.
                print("TIME OUT")
                return False
            for i in range(ObjectCount):
                rcvPACKET += ser.read(10)
            rcvPACKET += ser.read() #CHECKSUM
            chksum = 0
            for r in rcvPACKET:     #CHECKSUM 계산
                chksum ^= r
            if chksum != 0:         #CHECKSUM ERROR
                print("CHECK SUM ERROR")
                return False
            return True
    return False
            
# Initialize sensor port 2 as a uart device
ser = UARTDevice(Port.S3, 115200)
ser.clear()
rcvPACKET = b''

def READCAM(mode):
    global rcvPACKET
    ser.clear()
    ser.write(b'\xAA')
    ser.write(chr(mode&0xFF))
    timeStamp = time.time()
    while ser.waiting() < 19 and time.time() - timeStamp < 0.2:   #100ms 이내에 모든 data가 들어오길 기다린다.
        pass
    read = True
    if ser.waiting() >= 19:  # 수신 데이터가 있으면 (최소 사이즈는 5 바이트임)
        wait(1) 
        if readPacket():    # 데이터 수신에 성공했으면 Parsing 함
            tof1 = struct.unpack("<H",rcvPACKET[3:5])[0]
            tof2 = struct.unpack("<H",rcvPACKET[5:7])[0]
            yaw = struct.unpack("<f",rcvPACKET[7:11])[0]
            roll = struct.unpack("<f",rcvPACKET[11:15])[0]
            pitch = struct.unpack("<f",rcvPACKET[15:19])[0]
            object = list([])
            for n in range(ObjectCount):
                block_ = _parsing(rcvPACKET[n*10+20:(n+1)*10+30])
                block = Block(block_[0], block_[1], block_[2], block_[3], block_[4])
                object.append(block)

            return True, object, SensorData((tof2 / 10), yaw, pitch)
    print(rcvPACKET)
    return False, [], SensorData(0, 0, 0)
    

stop_watch.reset()
while True:
    temp = stop_watch.time()
    print(temp)
    print(READCAM(0))
    n = stop_watch.time()
    print(n)
    print(n - temp)