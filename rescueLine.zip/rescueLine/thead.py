#!/usr/bin/env pybricks-micropython
import time, struct
from pybricks.hubs import EV3Brick
from pybricks.ev3devices import (Motor, TouchSensor, ColorSensor,
                                 InfraredSensor, UltrasonicSensor, GyroSensor)
from pybricks.parameters import Port, Stop, Direction, Button, Color
from pybricks.tools import wait, StopWatch, DataLog
from pybricks.robotics import DriveBase
from pybricks.media.ev3dev import SoundFile, ImageFile
from ucollections import namedtuple
from pybricks.iodevices import UARTDevice

ev3 = EV3Brick()

left_motor = Motor(Port.B, gears=[20, 28])
right_motor = Motor(Port.C, Direction.COUNTERCLOCKWISE, gears=[20, 28])
imu = UARTDevice(Port.S4, 115200)
# touch = TouchSensor(Port.S3)

# pickup_motor = Motor(Port.D, gears=[12, 20])
# arm_motor = Motor(Port.A, gears=[12, 20])
# throw_motor = Motor(Port.D)
# robot = DriveBase(left_motor, right_motor, wheel_diameter=39.05, axle_track=163)
# clock = StopWatch()
stop_watch = StopWatch()
tof_clock = StopWatch()

def object_chasing(type, x_cut= (40, 40)):
    while True:
        exist, objectData, tof = object_detect(type, 0)
        if exist:
            x = objectData.x_center
            y = objectData.y_center
            if x > x_cut[0] or x < WIDTH - x_cut[1]:
                if tof[0] - tof[1] < 2:
                    pass
            speed = 1 if x > WIDTH/2 else -1
            robot.drive(0, 100 * speed)


        yield
    yield True