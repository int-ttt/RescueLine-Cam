#!/usr/bin/env pybricks-micropython

import time, struct, math

from pybricks.hubs import EV3Brick
from pybricks.ev3devices import Motor, ColorSensor
from pybricks.parameters import Port, Stop, Direction, Button
from pybricks.tools import wait, StopWatch
from pybricks.robotics import DriveBase
from ucollections import namedtuple
from pybricks.iodevices import UARTDevice
# -------------------------------------------- Device Setting -------------------------------------------- #
ev3 = EV3Brick()
ev3.speaker.beep()

left_motor = Motor(Port.B, gears=[12, 20, 28])
right_motor = Motor(Port.C, Direction.COUNTERCLOCKWISE, gears=[12, 20, 28])
pickup_motor = Motor(Port.D, gears=[12, 20])
throw_motor = Motor(Port.D)
l_color = ColorSensor(Port.S1)  # left color sensor
r_color = ColorSensor(Port.S2)  # right color sensor
robot = DriveBase(left_motor, right_motor, wheel_diameter=38.35, axle_track=157.1)
clock = StopWatch()
imu = UARTDevice(Port.S4, 115200)
# ---------------------------------------------- RGB Setting --------------------------------------------- #
# RGB 측정값 입력, RGBdata는 두개의 컬러센서 R, G, B의 측정값이다., 왼쪽+오른쪽
RGBdata = namedtuple('RGBdata', ['l_red','l_green','l_blue','r_red','r_green','r_blue'])
ObjectData = namedtuple('ObjectData', ['type', 'x_center', 'y_center', 'width', 'height'])
IMU = namedtuple('IMU', ['yaw', 'pitch', 'roll'])
# namedtuple로 만든 RGBdata는 클래스임. WHITE[1], WHITE[:3], WHITE.l_green으로 요소 접근
WHITE = RGBdata(33, 28, 77, 32, 30, 86)
BLACK = RGBdata(5, 4, 10, 5, 3, 10)
GREEN = RGBdata(8, 16, 12, 7, 17, 13)
SILVER = RGBdata(55, 38, 100, 56, 46, 100)
RED = RGBdata(29, 2, 7, 29, 3, 10)

# 라인경계값 정의
l_threshold = (WHITE.l_blue + BLACK.l_blue) // 2
r_threshold = (WHITE.r_blue + BLACK.r_blue) // 2
l_g_th = (WHITE.l_green + BLACK.l_green) // 2
r_g_th = (WHITE.r_green + BLACK.r_green) // 2
# ----------------------------------------------- Function ----------------------------------------------- #
print(imu)
def _read_register(register, length = 1) -> int:
    global ReadFail, imu
    
    while True:
        i = 0
        ReadFail = True

        while i < 10:
            imu.write(bytes([0xAA, 0x01, register, length]))
            w = StopWatch()
            now = w.time()
            while imu.waiting() < length + 2 and w.time() - now < 250:
                yield
            resp = imu.read(imu.waiting())
            if len(resp) >= 2 and resp[0] == 0xBB:
                ReadFail = False
                break
            #wait(10)
            i += 1
            yield
        if len(resp) < 2:                       #BNO055로부터의 응답은 최소 2바이트임, 2바이트보다 작으면 에러
            print("UART access error.")
        if resp[0] != 0xBB:                     #BNO055로부터의 정상적인 Data는 0xBB로 시작하며, 에러는 0xEE로 시작함.
            print('UART read error: ', resp[1])
        if length > 1:                          #요청한 Data의 사이즈가 1바이트 이상이면 Data 어레이 리턴, 아니면 1바이트만 리턴
            yield resp[2:]
        yield resp[2]

def _write_register(register: int, data: int) -> None:
    if not isinstance(data, bytes):
        data = bytes([data])
    print(bytes([0xAA, 0x00, register, len(data)]) + data)
    imu.write(bytes([0xAA, 0x00, register, len(data)]) + data)
    w = StopWatch()
    now = w.time()
    while imu.waiting() < 2 and w.time() - now < 700:
        print(imu.waiting())
        pass
    resp = imu.read(imu.waiting())
    if len(resp) < 2:
        print("UART access error.")
    if resp[0] != 0xEE or resp[1] != 0x01:
        print('UART write error: ', resp[1])



def euler() -> Tuple[float, float, float]:
    imu_task = _read_register(0x1A, 6)
    yield
    while True:
        while True:
            a = next(imu_task)
            if a is not None:
                break
            yield
        wait(10)
        if isinstance(a, int):
            yield
            continue
        resp = struct.unpack("<hhh", a)
        l =[]
        for x in resp:
            l.append(x / 16)
        _euler = tuple(l)
        yield IMU(_euler[0], _euler[1], _euler[2]-180 if _euler[2] > 0 else _euler[2]+180)

# dc() 메서드를 조향값으로 제어
def steering_dc(steering, power):
    # steering값이 100보다 크거나, -100보다 작은 값을 100 또는 -100으로 수정
    steering = max(-100, min(100, steering))
    if -100 <= steering < 0:
        left_motor.dc(round(((power * 2) / 100) * steering + power))
        right_motor.dc(power)
    elif 0 <= steering <= 100:
        left_motor.dc(power)
        right_motor.dc(round((-(power * 2) / 100) * steering + power))   

# drive() 메서드를 조향값으로 제어
def steering_drive(steering, speed):
    # steering값이 100보다 크거나, -100보다 작은 값을 100 또는 -100으로 수정
    steering = max(-100, min(100, steering))
    speed_val = speed * 0.01    # 중복계산 방지
    SPEED = round(-speed_val*abs(steering+50) - speed_val*abs(steering-50) + (speed*2))
    TURN = round(-speed_val*abs(steering-50) + speed_val*abs(steering+50))
    robot.drive(SPEED, TURN)

# 라인 수직정렬
def align(kp, range):
    if l_threshold > r_threshold:
        l = r_threshold / l_threshold
        r = 1
    else:
        l = 1
        r = l_threshold / r_threshold
    while True:
        err = (l_color.rgb()[2] * l) - (r_color.rgb()[2] * r)
        if -range <= err <= range:
            break
        robot.drive(0, err*kp)
    robot.stop(Stop.BRAKE)

# 라인트레이싱 함수
turn_direction =''; last_error = 0
def pid_control(l_rgb, r_rgb, drive_speed, kp, kd, imu_task, imu, st_range=15, over_angle=110):
    # 전역변수를 지역변수로
    global turn_direction, last_error
    gap = False
    # 라인트레이싱 - PD control
    error = l_rgb[2] - r_rgb[2]
    differential = error - last_error
    steering = (kp * error) + (kd * differential)
    #steering이 st_range 안에 있으면 직진
    if -st_range <= steering <= st_range:
        steering = 0
    # 이탈 했을 때 처리방법
    if l_rgb[1] < l_g_th and r_rgb[1] < r_g_th:
        pass
    elif l_rgb[1] < l_g_th:
        turn_direction = 'l'
    elif r_rgb[1] < r_g_th:
        turn_direction = 'r'
    # 라인이탈 감지
    if l_line == 4 and r_line == 4:
        robot.reset()
        sensors = None
        # 이탈후 라인 복귀
        if turn_direction == 'l':
            steering_drive(-100, drive_speed)
            while r_color.rgb()[2] > r_threshold:
                if sensors is None:
                    _imu = next(imu_task)
                    if not _imu is None:
                        sensors = _imu
                compare = abs(robot.angle())
                gap = compare > over_angle
                if gap:
                    break
        else:
            steering_drive(100, drive_speed)
            while l_color.rgb()[2] > l_threshold:
                if sensors is None:
                    _imu = next(imu_task)
                    if not _imu is None:
                        sensors = _imu
                compare = abs(robot.angle())
                gap = compare > over_angle
                if gap:
                    break
        # gap인 경우 처리
        if gap:
            if imu < -5:
                if sensors is not None and sensors.roll > -5:
                    robot.reset()
                    robot.stop()
                    robot.drive(70, 0)
                    while robot.distance() < 20:
                        pass
                    robot.stop(Stop.BRAKE)
                    return False
            robot.stop(Stop.BRAKE)
            robot.reset()
            if turn_direction == 'l':
                steering_drive(100, drive_speed)
            else:
                steering_drive(-100, drive_speed)
            # 만일 반대방향으로 더 많이 회전하면, compare-num, 조금 회전하면 compare+num
            while abs(robot.angle()) < compare:
                pass
            robot.stop(Stop.BRAKE)
            return gap
    else:
        steering_drive(steering, drive_speed)   # 라인트레이싱 동작
    last_error = error

# 색상측정결과를 모은 리스트를 분석해서 이후동작 결정하는 함수
def list_analyze(l_list, r_list):
    if l_list.count(5) >= 2 and r_list.count(5) >= 2:
        result = 'silver'
    elif l_list.count(3) >= 2 and r_list.count(3) >= 2:
        result = 'red'
    elif 2 in l_list[4:] and 2 in r_list[4:]:
        result = 'UTurn'
    elif 2 in l_list[4:] and 2 not in r_list[4:]:
        if 1 in l_list[:4]:
            result = 'straight'
        else:
            if 2 in r_list:
                result = 'UTurn'
            else:
                result = 'LTurn'
    elif 2 not in l_list[4:] and 2 in r_list[4:]:
        if 1 in r_list[:4]:
            result = 'straight'
        else:
            if 2 in l_list:
                result = 'UTurn'
            else:
                result = 'RTurn'
    else:
        result = 'none'
    return result

# beep음 재생함수
def beep(i = 1, sound=1000, deg=50):
    if i > 0:
        for j in range(i):
            ev3.speaker.beep(sound,deg)
PacketIndex = 0;ObjectIndex = 0;rcvPACKET = bytearray([]);Object = list([]);ObjectCount = 0
def _parsing(_data, n=5): # tuple([uInt16 * n])
    buf = struct.unpack("<" + 'h' * n, _data)
    return tuple(buf)
SensorData = namedtuple('SensorData', ['tof', 'pitch', 'roll']) # tof = [0~200, 0~200, 0~200, 0~200]cm, pitch = 0~360 (angle), roll = 0~ 360 (angle)
def readPacket() -> bool:
    global PacketIndex
    global ObjectIndex
    global rcvPACKET
    global ObjectCount
    global yaw, roll, pitch
    read = False
    rcvPACKET = bytearray([])
    rcvPACKET += ser.read()
    if rcvPACKET[0] == 0xAA or rcvPACKET[0] == '\x00':
        rcvPACKET += ser.read()
        if rcvPACKET[1] == 0xCC:
            rcvPACKET += ser.read()     # PACKET SeqNo
            rcvPACKET += ser.read(8)    # TOF1 거리 2 Bytes Unsigned Integer
            rcvPACKET += ser.read()     # OBJECT 갯수 1 Bytes Unsigned Integer
            ObjectCount = rcvPACKET[11]             
            timeStamp = time.time()
            while ser.waiting() < ObjectCount * 10 + 1 and time.time() - timeStamp < 1:   #100ms 이내에 모든 data가 들어오길 기다린다.
                pass
            wait(1)
            if ser.waiting() < ObjectCount * 10 + 1:     #정확한 사이즈의 DATA가 수신되지 않았음.
                print("TIME OUT")
                return False
            for i in range(ObjectCount):
                rcvPACKET += ser.read(10)
            rcvPACKET += ser.read() #CHECKSUM
            chksum = 0
            for r in rcvPACKET:     #CHECKSUM 계산
                chksum ^= r
            if chksum != 0:         #CHECKSUM ERROR
                print("CHECK SUM ERROR")
                return False
            return True
    return False
            
#Initialize sensor port 2 as a uart device
ser = UARTDevice(Port.S3, 115200)
ser.clear()
rcvPACKET = b''
exist, objects, sensors = False, [], SensorData([0,0,0,0], 0, 0)
def READCAM(mode):
    global rcvPACKET
    while True:
        ser.clear()
        ser.write(b'\xAA')
        ser.write(chr(mode&0xFF))
        timeStamp = time.time()
        while ser.waiting() < 19 and time.time() - timeStamp < 0.2:   #100ms 이내에 모든 data가 들어오길 기다린다.
            yield
        read = True
        if ser.waiting() >= 23:  # 수신 데이터가 있으면 (최소 사이즈는 5 바이트임)
            wait(1) 
            if readPacket():    # 데이터 수신에 성공했으면 Parsing 함
                tof = _parsing(rcvPACKET[3:11], 4)
                objects = list([])
                yield
                for n in range(ObjectCount):
                    block_ = _parsing(rcvPACKET[n*10+12:(n+1)*10+12])
                    object = ObjectData(block_[0], block_[1], block_[2], block_[3], block_[4])
                    objects.append(object)

                yield (True, objects, tof)
                continue
        print(rcvPACKET)
        yield (False, [], [0,0,0,0])


# READCAM(0) # use exist, objects, sensors ; objects는 exist가 True일때만 값이 존재하고 sensors는 데이터 오류가 나서 모든 데이터가 0이 아니면 제대로 불러와진 상태
    # if sensors.tof[0] < 200 or sensors.tof[1] < 200:
    #     l = 's'



# ------------------------------------------ coroutine function ------------------------------------------ #

# 색상측정함수
def color_detect():
    # green 계산 기준값
    l_green = round(((GREEN[:3][1]/sum(GREEN[:3]))*100) - ((GREEN[:3][0]/(GREEN[:3][0]+GREEN[:3][1]))*100))
    r_green = round(((GREEN[3:][1]/sum(GREEN[3:]))*100) - ((GREEN[3:][0]/(GREEN[3:][0]+GREEN[3:][1]))*100))
    # 색상측정 계산을 위한 함수
    def rgb_distance(rgb_2, rgb_1, green = False):
        if green:
            if rgb_2.count(0) != 0:
                rgb_2 = [1 if x==0 else x for x in rgb_2]   # RGB 튜플값 중 0이 있으면 1로 바꿈
            green_val = round(((rgb_2[1]/sum(rgb_2))*100) - ((rgb_2[0]/(rgb_2[0]+rgb_2[1]))*100))
            green_thre = round(((rgb_1[1]/sum(rgb_1))*100) - ((rgb_1[0]/(rgb_1[0]+rgb_1[1]))*100))
            result = abs(green_val - green_thre)
        else:
            result = (((rgb_2[0]-rgb_1[0])**2) + ((rgb_2[1]-rgb_1[1])**2) + ((rgb_2[2]-rgb_1[2])**2))**0.5
        return result
    # 색상측정 none:0, black:1, green:2, red:3, white:4, silver:5
    while True:
        l_rgb = l_color.rgb()
        r_rgb = r_color.rgb()
        if rgb_distance(l_rgb, SILVER[:3]) <= 10:
            l_line = 5
        elif rgb_distance(l_rgb, RED[:3]) <= 10:
            l_line = 3
        elif rgb_distance(l_rgb, l_green, True) <= 8 and sum(l_rgb) > 10:
            l_line = 2
        elif rgb_distance(l_rgb, WHITE[:3]) <= 10:
            l_line = 4
        elif rgb_distance(l_rgb, BLACK[:3]) <= 10:
            l_line = 1
        else:
            l_line = 0
        if rgb_distance(r_rgb, SILVER[3:]) <= 10:
            r_line = 5
        elif rgb_distance(r_rgb, RED[3:]) <= 10:
            r_line = 3
        elif rgb_distance(r_rgb, r_green, True) <= 8 and sum(r_rgb) > 10:
            r_line = 2
        elif rgb_distance(r_rgb, WHITE[3:]) <= 10:
            r_line = 4
        elif rgb_distance(r_rgb, BLACK[3:]) <= 10:
            r_line = 1
        else:
            r_line = 0
        yield (l_rgb, r_rgb, l_line, r_line)

# gap 처리
def gap_action():
    while True:
        robot.reset()
        robot.drive(-50, 0)
        while robot.distance() > -25:
            yield           # 동시동작 계속
        robot.stop(Stop.BRAKE)
        # align(kp, range)
        # align(0.5, 0.5)
        robot.reset()
        robot.drive(70, 0)
        while robot.distance() < 230:
            yield           # 동시동작 계속
        robot.stop(Stop.BRAKE)
        if l_color.rgb()[2] < l_threshold or r_color.rgb()[2] < r_threshold:
            gap = False     # 동시동작 종료
            yield gap
        else:
            robot.reset()
            while l_color.rgb()[2] > l_threshold and robot.angle() > -85:
                robot.drive(150, -150)
                yield       # 동시동작 계속
            robot.stop(Stop.BRAKE)
            if robot.angle() < -83:
                while robot.angle() < 0:
                    robot.drive(-150, 150)
                    yield   # 동시동작 계속
                while l_color.rgb()[2] > l_threshold:
                    robot.drive(150, 150)
                    yield   # 동시동작 계속
                robot.stop(Stop.BRAKE)
                gap = False # 동시동작 종료
                yield gap
            else:
                gap = False # 동시동작 종료
                yield gap

# 교차로 초록색 처리
def green_action(detect_task):
    while True:
        if line_then == 'straight':
            robot.reset()
            while robot.distance() < 70:
                robot.drive(70, 0)
                yield       # 동시동작 계속
            green = False   # 동시동작 종료
            yield green
        elif line_then == 'UTurn':
            robot.reset()
            while robot.angle() < 200:
                robot.drive(0, 70)
                yield       # 동시동작 계속
            while l_color.rgb()[2] < r_threshold:
                robot.drive(0,70)
                align(4, 4)
                yield       # 동시동작 계속
            robot.stop(Stop.BRAKE)
            green = False   # 동시동작 종료
            yield green
        elif line_then == 'LTurn':
            if sensors.roll < -7:
                robot.reset()
                while robot.distance() < 120:
                    robot.drive(70, 0)
                    yield
                robot.stop(Stop.BRAKE)
                while robot.angle() > -95:
                    robot.drive(0, -70)
                    yield
                robot.stop(Stop.BRAKE)
                robot.reset()
                while True:
                    l_blue, r_blue, l_line, r_line = next(detect_task)
                    print(l_line)
                    if robot.distance() > 80 or l_line == 2:
                        break
                    robot.drive(70, 0)
                    yield
                robot.stop(Stop.BRAKE)
                
                if l_line == 2:
                    ev3.speaker.beep()
                    robot.straight(5)
                else:
                    while robot.angle() < 90:
                        robot.drive(0, 70)
                        yield
                    robot.stop(Stop.BRAKE)
                green = False
            else:
                robot.reset()
                while robot.distance() < 50:
                    robot.drive(70, 0)
                    yield
                robot.stop(Stop.BRAKE)
                while robot.angle() > -70:
                    robot.drive(0, -70)
                    yield
                while r_color.rgb()[2] < r_threshold:
                    robot.drive(0, -70)
                    yield
                robot.stop(Stop.BRAKE)
                green = False
            yield green
        elif line_then == 'RTurn':
            if sensors.roll < -7:
                robot.reset()
                while robot.distance() < 120:
                    robot.drive(70, 0)
                    yield
                robot.stop(Stop.BRAKE)
                while robot.angle() < 90:
                    robot.drive(0, 70)
                    yield
                robot.stop(Stop.BRAKE)
                robot.reset()
                while True:
                    l_blue, r_blue, l_line, r_line = next(detect_task)
                    if robot.distance() > 80 or r_line == 2:
                        break
                    robot.drive(70, 0)
                    yield
                robot.stop(Stop.BRAKE)
                
                if r_line == 2:
                    robot.straight(5)
                else:
                    while robot.angle() > -90:
                        robot.drive(0, -70)
                        yield
                    robot.stop(Stop.BRAKE)
                green = False
            else:
                robot.reset()
                while robot.distance() < 50:
                    robot.drive(70, 0)
                    yield
                robot.stop(Stop.BRAKE)
                while robot.angle() < 70:
                    robot.drive(0, 70)
                    yield
                robot.stop(Stop.BRAKE)
                while l_color.rgb()[2] < l_threshold:
                    robot.drive(0, 70)
                robot.stop(Stop.BRAKE)
                green = False
            yield green

# def hill_action():
#     while True:
#         robot.reset()
#         if gap == 2:

def obstacle_action():
    while True:
        robot.reset()
        while robot.angle() < 90:
            robot.drive(0, 70)
            yield
        robot.stop(Stop.BRAKE)
        while robot.distance() < 50:
            robot.drive(70, 0)
            yield
        robot.stop(Stop.BRAKE)
        while robot.angle() > -90:
            robot.drive(0, -70)
            yield
        robot.stop(Stop.BRAKE)
        while robot.distance() < 100:
            robot.drive(70, 0)
            yield
        robot.stop(Stop.BRAKE)
        while robot.angle() > -90:
            robot.drive(0, 70)
            yield
        while robot.distance() < 100:
            robot.drive(70, 0)
            yield
        robot.stop(Stop.BRAKE)
        robot.stop(Stop.BRAKE)
        obstacle = False
        yield obstacle

def silver_action():
    pass

# --------------------------------------------- Main Program --------------------------------------------- #

wait(700)
_write_register(0x3D, 0x00) #동작모드를 CONFIG로 변경
wait(20)
_write_register(0x3D, 0x08) #동작모드를 IMU로 변경
wait(20)

pickup_motor.run(1500)
wait(10)
while not pickup_motor.control.stalled():
    pass
pickup_motor.stop()
robot.drive(50, 0)
cam_task = READCAM(0)
while True:
    cam = next(cam_task)
    if cam is not None:
        a, b, tof = cam
        print(cam)
        if tof[0] < 80 or tof[1] < 80 or (abs(tof[0] - tof[1]) < 10 and tof[0] < 120):
            break

robot.stop(Stop.BRAKE)
pickup_motor.run(-2000)
wait(10)
while not pickup_motor.control.stalled():
    pass
pickup_motor.stop()


