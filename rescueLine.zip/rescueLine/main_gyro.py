#!/usr/bin/env pybricks-micropython
from pybricks.hubs import EV3Brick
from pybricks.ev3devices import (Motor, TouchSensor, ColorSensor,
                                 InfraredSensor, UltrasonicSensor, GyroSensor)
from pybricks.parameters import Port, Stop, Direction, Button, Color
from pybricks.tools import wait, StopWatch, DataLog
from pybricks.robotics import DriveBase
from pybricks.media.ev3dev import SoundFile, ImageFile

# --------------------------------- 장치설정 --------------------------------- #
ev3 = EV3Brick()
lm = Motor(Port.B, gears=[12, 20])
rm = Motor(Port.C, gears=[12, 20])
# ul = UltrasonicSensor(Port.S1)
gy = GyroSensor(Port.S1)
robot = DriveBase(lm, rm, wheel_diameter=73.21, axle_track = 257)
ev3.speaker.beep()

# ----------------------------------- 함수 ----------------------------------- #
while True:
    print(gy.angle())


# ----------------------------------- main ----------------------------------- #

